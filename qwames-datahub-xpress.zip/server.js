require("dotenv").config();
const express = require("express");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const XPRESS_BASE_URL = (process.env.XPRESS_BASE_URL || "https://resellerxpress.shop/api/v1").replace(/\/+$/, "");

app.use(express.json());
app.use(express.static("public"));

function xpressHeaders() {
  if (!process.env.XPRESS_API_KEY) throw new Error("XPRESS_API_KEY is not configured");
  return {
    "X-API-KEY": process.env.XPRESS_API_KEY,
    "Content-Type": "application/json",
    "Accept": "application/json"
  };
}

async function xpress(path, options={}) {
  const response = await fetch(`${XPRESS_BASE_URL}${path}`, {
    ...options,
    headers: {...xpressHeaders(), ...(options.headers || {})}
  });
  const text = await response.text();
  let data;
  try { data = JSON.parse(text); } catch { data = {raw:text}; }
  if (!response.ok) {
    const e = new Error(data?.message || `Xpress HTTP ${response.status}`);
    e.status = response.status;
    e.data = data;
    throw e;
  }
  return data;
}

app.get("/api/health", (_req,res)=>res.json({ok:true,service:"Qwame's Data Hub"}));

app.get("/api/plans", async (req,res)=>{
  try {
    const network = req.query.network ? `?network=${encodeURIComponent(req.query.network)}` : "";
    res.json(await xpress(`/plans${network}`));
  } catch(e) {
    res.status(e.status || 500).json({ok:false,error:e.message,data:e.data});
  }
});

app.get("/api/wallet", async (_req,res)=>{
  try { res.json(await xpress("/wallet-balance")); }
  catch(e) { res.status(e.status || 500).json({ok:false,error:e.message}); }
});

app.post("/api/orders", async (req,res)=>{
  try {
    const {plan_id, phone, request_id, quantity=1} = req.body || {};
    if (!plan_id || !phone) return res.status(400).json({ok:false,error:"plan_id and phone are required"});
    const id = request_id || `QDH_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
    const result = await xpress("/place-order", {
      method:"POST",
      body:JSON.stringify({plan_id:Number(plan_id),phone:String(phone),request_id:id,quantity:Number(quantity)})
    });
    res.status(202).json(result);
  } catch(e) {
    res.status(e.status || 500).json({ok:false,error:e.message,data:e.data});
  }
});

app.get("/api/orders/:requestId", async (req,res)=>{
  try { res.json(await xpress(`/order-status?request_id=${encodeURIComponent(req.params.requestId)}`)); }
  catch(e) { res.status(e.status || 500).json({ok:false,error:e.message}); }
});

/* Xpress -> Qwame's Data Hub webhook */
app.post("/api/webhooks/xpress", (req,res)=>{
  // Store/update your order in a database here in production.
  // Xpress documentation currently specifies order_success/order_failed events.
  console.log("Xpress webhook:", JSON.stringify(req.body));
  res.sendStatus(200);
});

/* Optional helper: configure Xpress to call our webhook. */
app.post("/api/xpress/configure-webhook", async (req,res)=>{
  try {
    const base = process.env.PUBLIC_BASE_URL;
    if (!base) return res.status(400).json({ok:false,error:"PUBLIC_BASE_URL is not configured"});
    const result = await xpress("/webhook", {
      method:"POST",
      body:JSON.stringify({
        url:`${base.replace(/\/+$/,"")}/api/webhooks/xpress`,
        enabled:true,
        events:["order_success","order_failed"]
      })
    });
    res.json(result);
  } catch(e) {
    res.status(e.status || 500).json({ok:false,error:e.message,data:e.data});
  }
});

/* Paystack webhook placeholder: keep the Paystack secret server-side. */
app.post("/api/webhooks/paystack",(req,res)=>{
  const signature=req.headers["x-paystack-signature"];
  if (!signature || !process.env.PAYSTACK_SECRET_KEY) return res.status(401).json({ok:false,error:"Paystack webhook not configured"});
  const expected=crypto.createHmac("sha512",process.env.PAYSTACK_SECRET_KEY).update(JSON.stringify(req.body)).digest("hex");
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))
    return res.status(401).json({ok:false,error:"Invalid signature"});
  console.log("Paystack event:",req.body.event);
  // TODO: map paid metadata to Xpress plan_id + phone, then POST /api/orders.
  res.sendStatus(200);
});

app.listen(PORT,()=>console.log(`Qwame's Data Hub listening on ${PORT}`));
