# Qwame's Data Hub — Xpress reseller integration

Base URL from the official ResellerXpress docs:
https://resellerxpress.shop/api/v1

Implemented server routes:
- GET /api/plans
- GET /api/wallet
- POST /api/orders -> Xpress POST /place-order
- GET /api/orders/:requestId -> Xpress GET /order-status
- POST /api/webhooks/xpress
- POST /api/xpress/configure-webhook -> Xpress POST /webhook
- POST /api/webhooks/paystack (signature verification placeholder)

Xpress webhook events documented:
order_success, order_failed

IMPORTANT:
1. The API key shown in the screenshot you uploaded is exposed. Revoke/regenerate it immediately and put the NEW key only in .env.
2. Never put the Xpress API key in public/index.html or browser JavaScript.
3. Set PUBLIC_BASE_URL to your deployed HTTPS URL before configuring the webhook.
4. The Paystack-to-Xpress automatic fulfillment still needs the Paystack checkout flow and your chosen retail pricing rules.
